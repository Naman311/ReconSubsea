Arduino Library for TI's HDC1050/HDC1080 Temperature and Humidity Sensor

This is an Arduino Library for TI's HDC1050/HDC1080 Temperature and Humidity Sensor. More details can be found here:

<a href="http://www.kerrywong.com/2015/10/16/interfacing-hdc1050-with-arduino/">Interfacing HDC1050 with Arduino</a>
